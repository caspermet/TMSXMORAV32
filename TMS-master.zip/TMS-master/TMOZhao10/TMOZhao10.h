#include "TMO.h"

class TMOZhao10 : public TMO  
{
public:
	TMOZhao10();
	virtual ~TMOZhao10();
	virtual int Transform();

protected:
	TMODouble dParameter;
};
