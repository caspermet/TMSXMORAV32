// TMOFilters.h: interface for the TMOFilters class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TMOFILTERS_H__C3A16DCD_4F60_42BB_8B1F_BBA86096DF64__INCLUDED_)
#define AFX_TMOFILTERS_H__C3A16DCD_4F60_42BB_8B1F_BBA86096DF64__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <qwidget.h>

class TMOFilters : public QWidget  
{
public:
	TMOFilters();
	virtual ~TMOFilters();

};

#endif // !defined(AFX_TMOFILTERS_H__C3A16DCD_4F60_42BB_8B1F_BBA86096DF64__INCLUDED_)
