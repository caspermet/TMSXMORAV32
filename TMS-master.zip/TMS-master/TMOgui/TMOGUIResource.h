#ifndef TMORESOURCE
#define TMORESOURCE

#include "resources5.h"

class TMOResource
{
public:
	static TMOGUIResource *pResource;
};

#endif //TMORESOURCE
