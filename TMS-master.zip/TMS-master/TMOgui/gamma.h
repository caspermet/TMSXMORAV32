#ifndef GAMMA_H
#define GAMMA_H

#define GAMMA_MAX 20
#define INV_GAMMA_MAX 0.05

#define GAMMA_MIN 0.2
#define INV_GAMMA_MIN 5.0

#endif
