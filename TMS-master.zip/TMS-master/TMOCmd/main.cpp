#include "TMOCmd.h"

int main (int argc, char *argv[])
{
	TMOCmd cmd;
	return cmd.main(argc, argv);
}

